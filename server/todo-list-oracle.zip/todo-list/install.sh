#!/usr/bin/env bash
# To Do List — install or update on your own Linux server (Oracle Cloud Always Free VM, Ubuntu or Oracle Linux).
# Run:  sudo bash install.sh
# Re-run any time to update. Your tasks (in /opt/todo-list/data) are kept.
set -euo pipefail

APP=/opt/todo-list
PORT=8787
say()  { printf '\n\033[1;32m==> %s\033[0m\n' "$*"; }
warn() { printf '\033[1;33m%s\033[0m\n' "$*"; }
die()  { printf '\n\033[1;31mERROR: %s\033[0m\n' "$*"; exit 1; }

[ "$(id -u)" -eq 0 ] || exec sudo bash "$0" "$@"
SRC="$(cd "$(dirname "$0")" && pwd)"
[ -f "$SRC/server.js" ] || die "Run this from inside the unzipped todo-list folder."

case "$(uname -m)" in
  x86_64)        NODE_ARCH=x64;   CADDY_ARCH=amd64 ;;
  aarch64|arm64) NODE_ARCH=arm64; CADDY_ARCH=arm64 ;;
  *) die "Unsupported CPU: $(uname -m)" ;;
esac
port_busy() { (exec 3<>/dev/tcp/127.0.0.1/"$1") 2>/dev/null; }

say "1/6  Node.js"
NEED_NODE=1
if command -v node >/dev/null 2>&1; then
  [ "$(node -p 'process.versions.node.split(".")[0]')" -ge 18 ] && NEED_NODE=0
fi
if [ "$NEED_NODE" = 1 ]; then
  V=v20.18.0
  curl -fsSL "https://nodejs.org/dist/$V/node-$V-linux-$NODE_ARCH.tar.xz" -o /tmp/node.tar.xz
  tar -xJf /tmp/node.tar.xz -C /usr/local --strip-components=1
  rm -f /tmp/node.tar.xz
fi
NODE_BIN="$(command -v node)"
echo "Node $("$NODE_BIN" -v) at $NODE_BIN"

say "2/6  App files -> $APP"
mkdir -p "$APP/data"
cp -r "$SRC/server.js" "$SRC/push.js" "$SRC/logic.js" "$SRC/package.json" "$APP/"
rm -rf "$APP/public" && cp -r "$SRC/public" "$APP/public"
id todo >/dev/null 2>&1 || useradd --system --home-dir "$APP" --shell /usr/sbin/nologin todo 2>/dev/null || useradd -r -d "$APP" -s /sbin/nologin todo
chown -R todo:todo "$APP"

say "3/6  Background service (starts by itself after a reboot)"
cat > /etc/systemd/system/todo-list.service <<EOF
[Unit]
Description=To Do List
After=network-online.target
Wants=network-online.target

[Service]
User=todo
WorkingDirectory=$APP
Environment=PORT=$PORT
Environment=HOST=127.0.0.1
ExecStart=$NODE_BIN $APP/server.js
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF
systemctl daemon-reload
systemctl enable todo-list >/dev/null 2>&1
systemctl restart todo-list
for _ in $(seq 1 20); do curl -fs "http://127.0.0.1:$PORT/api/config" >/dev/null && break; sleep 0.5; done
curl -fs "http://127.0.0.1:$PORT/api/config" >/dev/null || die "App did not start. See: journalctl -u todo-list -n 50"
echo "App is running on this server."

say "4/6  Web address"
if [ -z "${DOMAIN:-}" ]; then
  IP="$(curl -fs4 --max-time 10 https://api.ipify.org || curl -fs4 --max-time 10 https://ifconfig.me || true)"
  [ -n "$IP" ] || die "Could not find this server's public IP."
  DOMAIN="$(echo "$IP" | tr . -).sslip.io"
fi
echo "Address: https://$DOMAIN"

say "5/6  HTTPS (needed for install + notifications on phones)"
HTTPS_OK=1
if pgrep -x caddy >/dev/null 2>&1 && [ ! -f /etc/caddy/todo-list.caddy ] && [ -f /etc/caddy/Caddyfile ] && ! grep -q "todo-list.caddy" /etc/caddy/Caddyfile; then
  # Caddy already used by something else on this server: add our site to it
  printf '%s {\n\treverse_proxy 127.0.0.1:%s\n}\n' "$DOMAIN" "$PORT" > /etc/caddy/todo-list.caddy
  printf '\nimport /etc/caddy/todo-list.caddy\n' >> /etc/caddy/Caddyfile
  (caddy reload --config /etc/caddy/Caddyfile || systemctl reload caddy) && echo "Added to your existing Caddy."
elif [ -f /etc/systemd/system/todo-caddy.service ] || ! { port_busy 80 || port_busy 443; }; then
  if [ ! -x /usr/local/bin/caddy ]; then
    curl -fsSL "https://caddyserver.com/api/download?os=linux&arch=$CADDY_ARCH" -o /usr/local/bin/caddy
    chmod +x /usr/local/bin/caddy
  fi
  mkdir -p /etc/todo-caddy /var/lib/todo-caddy
  printf '{\n\tstorage file_system /var/lib/todo-caddy\n}\n%s {\n\tencode gzip\n\treverse_proxy 127.0.0.1:%s\n}\n' "$DOMAIN" "$PORT" > /etc/todo-caddy/Caddyfile
  cat > /etc/systemd/system/todo-caddy.service <<EOF
[Unit]
Description=HTTPS for To Do List (Caddy)
After=network-online.target
Wants=network-online.target

[Service]
ExecStart=/usr/local/bin/caddy run --config /etc/todo-caddy/Caddyfile
ExecReload=/usr/local/bin/caddy reload --config /etc/todo-caddy/Caddyfile
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
  systemctl daemon-reload
  systemctl enable todo-caddy >/dev/null 2>&1
  systemctl restart todo-caddy
else
  HTTPS_OK=0
  warn "Ports 80/443 are already used by another program on this server (maybe nginx for your bot)."
  warn "Add this to that web server, then open https://$DOMAIN :"
  echo
  echo "  # nginx example"
  echo "  server {"
  echo "    listen 443 ssl; server_name $DOMAIN;"
  echo "    # (your ssl_certificate lines)"
  echo "    location / { proxy_pass http://127.0.0.1:$PORT; proxy_set_header Host \$host; }"
  echo "  }"
fi

say "6/6  Firewall on this server (ports 80 + 443)"
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --permanent --add-service=http --add-service=https >/dev/null && firewall-cmd --reload >/dev/null
  echo "firewalld: opened 80/443"
elif command -v iptables >/dev/null 2>&1; then
  for p in 80 443; do
    iptables -C INPUT -p tcp --dport "$p" -m state --state NEW -j ACCEPT 2>/dev/null || iptables -I INPUT 1 -p tcp --dport "$p" -m state --state NEW -j ACCEPT
  done
  if command -v netfilter-persistent >/dev/null 2>&1; then netfilter-persistent save >/dev/null 2>&1 || true
  elif [ -d /etc/iptables ]; then iptables-save > /etc/iptables/rules.v4; fi
  echo "iptables: opened 80/443"
fi

if [ "$HTTPS_OK" = 1 ]; then
  say "Checking https://$DOMAIN from the internet (can take up to a minute the first time)..."
  OK=0
  for _ in $(seq 1 30); do
    if curl -fs --max-time 5 "https://$DOMAIN/api/config" >/dev/null; then OK=1; break; fi
    sleep 3
  done
  if [ "$OK" = 1 ]; then
    printf '\n\033[1;32m================================================\n  DONE.  Open on your phone:\n  https://%s\n================================================\033[0m\n\n' "$DOMAIN"
  else
    warn "The app runs, but https://$DOMAIN is not reachable yet."
    warn "Oracle Cloud blocks ports 80/443 by default. Open them once:"
    echo "  Oracle Cloud console -> Networking -> Virtual cloud networks -> (your VCN)"
    echo "  -> Security Lists -> Default Security List -> Add Ingress Rules:"
    echo "     Source CIDR 0.0.0.0/0, IP Protocol TCP, Destination Port Range 80,443"
    echo "Then run:  sudo systemctl restart todo-caddy   and open https://$DOMAIN"
  fi
fi
echo "Status:  systemctl status todo-list     Logs:  journalctl -u todo-list -f"
echo "Your data: $APP/data (daily copies in $APP/data/backups)"
