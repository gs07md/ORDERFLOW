TO DO LIST - on your own Oracle Cloud server
=============================================

No request limits, no credits: it runs on your Oracle Always Free VM.

INSTALL (one time, about 3 minutes)
-----------------------------------
1. Copy todo-list-oracle.zip to your Oracle VM
   (WinSCP, or:  scp todo-list-oracle.zip ubuntu@YOUR-VM-IP:~ )

2. On the VM (SSH), run these two lines:

     python3 -m zipfile -e todo-list-oracle.zip .
     sudo bash todo-list/install.sh

3. At the end it prints your link, like:
     https://140-238-1-2.sslip.io
   Open it on your phone -> create your PIN -> "Add to Home screen".

If it says the link is "not reachable yet":
   Oracle Cloud console -> Networking -> Virtual cloud networks -> your VCN
   -> Security Lists -> Default Security List -> Add Ingress Rules
      Source CIDR: 0.0.0.0/0   IP Protocol: TCP   Destination Port Range: 80,443
   Then on the VM:  sudo systemctl restart todo-caddy

UPDATE LATER
------------
Copy the new zip, run the same two lines. Your tasks are kept.

USEFUL
------
Status:   systemctl status todo-list
Logs:     journalctl -u todo-list -f
Data:     /opt/todo-list/data   (daily copies in /opt/todo-list/data/backups)
Own domain instead of sslip.io:   sudo DOMAIN=todo.yourdomain.com bash todo-list/install.sh
