// Pure helpers shared by the Durable Object (no storage, no network).
export const pad = n => String(n).padStart(2, "0");
export const validId = id => typeof id === "string" && /^[A-Za-z0-9-]{8,64}$/.test(id);
export const validPin = p => typeof p === "string" && /^\d{4,8}$/.test(p);
const str = (v, n) => (typeof v === "string" ? v.slice(0, n) : "");
const num = v => (Number.isFinite(v) ? Math.round(v) : null);
const REP = ["daily", "weekdays", "weekly", "monthly"];

export function cleanTask(t) {
  if (!t || typeof t.id !== "string" || t.id.length > 40) return null;
  return {
    id: t.id, title: str(t.title, 200), due: num(t.due), prio: [1, 2, 3, 4].includes(t.prio) ? t.prio : 4,
    repeat: REP.includes(t.repeat) ? t.repeat : "none", cat: str(t.cat, 30), note: str(t.note, 500),
    who: str(t.who, 30), tone: str(t.tone, 12), done: !!t.done, doneAt: num(t.doneAt), lastDoneAt: num(t.lastDoneAt),
    created: num(t.created), u: num(t.u) || 0, deleted: !!t.deleted, allDay: !!t.allDay,
    phone: str(t.phone, 20), cname: str(t.cname, 40), act: ["call", "wa", "wacall"].includes(t.act) ? t.act : "", msg: str(t.msg, 500),
    items: Array.isArray(t.items) ? t.items.slice(0, 40).map(i => ({ t: str(i && i.t, 120), d: !!(i && i.d) })) : [],
  };
}
const MODES = ["cash", "upi", "card", "bank"];
export function cleanExp(x) {
  if (!x || typeof x.id !== "string" || !x.id || x.id.length > 40) return null;
  const a = Number(x.a), at = num(x.at);
  if (!Number.isFinite(a) || a === 0 || !at || at <= 0) return null;
  return {
    id: x.id, a: Math.round(Math.min(Math.abs(a), 1e9) * 100) / 100, t: x.t === "in" ? "in" : "out",
    c: str(x.c, 30), n: str(x.n, 200), m: MODES.includes(x.m) ? x.m : "cash", at, u: num(x.u) || 0, deleted: !!x.deleted,
  };
}
export function cleanDoc(x) {
  if (!x || typeof x.id !== "string" || !x.id || x.id.length > 40) return null;
  if (!["habit", "list"].includes(x.k)) return null;
  const d = x.d && typeof x.d === "object" && !Array.isArray(x.d) ? x.d : {};
  const body = JSON.stringify(d);
  if (body.length > 60000) return null;
  return { id: x.id, k: x.k, u: num(x.u) || 0, deleted: !!x.deleted, d: JSON.parse(body) };
}
export function cleanSub(s) {
  return s && typeof s.endpoint === "string" && /^https:\/\//.test(s.endpoint) && s.keys
    ? { endpoint: s.endpoint, keys: { p256dh: str(s.keys.p256dh, 200), auth: str(s.keys.auth, 100) } } : null;
}

export async function hashPin(salt, pin) {
  const d = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(salt + ":" + pin));
  return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, "0")).join("");
}
export function randHex(n) { return [...crypto.getRandomValues(new Uint8Array(n))].map(b => b.toString(16).padStart(2, "0")).join(""); }

export function localTime(ts, tzOff) {
  const d = new Date(ts + (tzOff ?? 330) * 60000);
  let h = d.getUTCHours();
  const ap = h >= 12 ? "pm" : "am";
  h = h % 12 || 12;
  return h + ":" + pad(d.getUTCMinutes()) + ap;
}
export function localDay(ts, tzOff) { return new Date(ts + (tzOff ?? 330) * 60000).toISOString().slice(0, 10); }

export function nextDue(t, now, tzOff = 330) {
  const d = new Date(t.due);
  let guard = 0;
  const sunday = ms => new Date(ms + tzOff * 60000).getUTCDay() === 0;
  do {
    if (t.repeat === "daily" || t.repeat === "weekdays") d.setUTCDate(d.getUTCDate() + 1);
    else if (t.repeat === "weekly") d.setUTCDate(d.getUTCDate() + 7);
    else if (t.repeat === "monthly") d.setUTCMonth(d.getUTCMonth() + 1);
    else return null;
  } while ((d.getTime() <= now || (t.repeat === "weekdays" && sunday(d.getTime()))) && ++guard < 400);
  return d.getTime();
}

export function visibleTasks(dev, list) {
  const mine = t => !(dev.settings?.mine && dev.name && t.who && t.who !== dev.name);
  return (list?.tasks || []).filter(t => !t.done && !t.deleted && t.due && mine(t));
}

/** When this device next needs attention (a ring, a repeat, an early reminder, the morning summary). */
export function computeNext(dev, list, s, now) {
  if (!dev || !dev.sub || !list) return null;
  if (s?.dead && s.dead === dev.sub.endpoint) return null;
  const sent = s?.sent || {}, pre = s?.pre || {}, acks = dev.acks || {};
  const repeat = dev.settings?.repeat || 3, preMin = dev.settings?.pre || 0;
  let next = Infinity;
  for (const t of visibleTasks(dev, list)) {
    const k = t.id + ":" + t.due;
    if (t.repeat && t.repeat !== "none") next = Math.min(next, t.due + 2 * 3600e3); // roll forward if never done
    if (t.allDay || acks[t.id] === t.due) continue;
    if (now - t.due < 2 * 3600e3) {
      const e = sent[k] || { n: 0, at: 0 };
      if (e.n < repeat) next = Math.min(next, e.n === 0 ? t.due : e.at + 60000);
    }
    if (preMin > 0 && !pre[k] && t.due - preMin * 60000 > now - 120000) next = Math.min(next, t.due - preMin * 60000);
  }
  const sum = dev.settings?.summary;
  if (sum) {
    const tz = dev.tzOff ?? 330;
    const [sh, sm] = sum.split(":").map(Number);
    const lt = new Date(now + tz * 60000);
    const dayStart = Date.UTC(lt.getUTCFullYear(), lt.getUTCMonth(), lt.getUTCDate()) - tz * 60000;
    let at = dayStart + (sh * 60 + sm) * 60000;
    if (s?.summaryDay === localDay(now, tz) || now > at + 180 * 60000) at += 864e5;
    next = Math.min(next, at);
  }
  return Number.isFinite(next) ? next : null;
}
