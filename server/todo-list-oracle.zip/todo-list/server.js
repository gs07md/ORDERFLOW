// To Do List — self-hosted server. Node 18+, no npm packages.
// Serves the app, keeps data in ./data/db.json, and sends push reminders at the exact time.
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { sendPush, b64u } from "./push.js";
import * as L from "./logic.js";

const DIR = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC = path.join(DIR, "public");
const DATA = process.env.DATA_DIR || path.join(DIR, "data");
const PORT = +process.env.PORT || 8787;
const HOST = process.env.HOST || "127.0.0.1";
fs.mkdirSync(DATA, { recursive: true });

/* ---------- push keys: made once, kept in data/keys.json ---------- */
async function loadKeys() {
  const f = path.join(DATA, "keys.json");
  if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, "utf8"));
  const kp = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
  const pub = b64u.enc(await crypto.subtle.exportKey("raw", kp.publicKey));
  const priv = (await crypto.subtle.exportKey("jwk", kp.privateKey)).d;
  const keys = { VAPID_PUBLIC: pub, VAPID_PRIVATE: priv, VAPID_SUBJECT: "mailto:todo-list@localhost" };
  fs.writeFileSync(f, JSON.stringify(keys, null, 1), { mode: 0o600 });
  return keys;
}
const env = await loadKeys();

/* ---------- storage: one JSON file, written safely ---------- */
const DB = path.join(DATA, "db.json");
let db = { owner: null, list: { tasks: [] }, devices: {}, state: {}, exps: { items: [], meta: null, seq: 0 } };
try { db = { ...db, ...JSON.parse(fs.readFileSync(DB, "utf8")) }; } catch {}
let saveT = null;
function saveNow() {
  clearTimeout(saveT); saveT = null;
  const tmp = DB + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db));
  fs.renameSync(tmp, DB);
}
const save = () => { if (!saveT) saveT = setTimeout(saveNow, 150); };
for (const sig of ["SIGINT", "SIGTERM"]) process.on(sig, () => { if (saveT) saveNow(); process.exit(0); });

/* ---------- daily backup copy (keeps last 7) ---------- */
function backup() {
  try {
    const dir = path.join(DATA, "backups"); fs.mkdirSync(dir, { recursive: true });
    const f = path.join(dir, "db-" + new Date().toISOString().slice(0, 10) + ".json");
    if (!fs.existsSync(f) && fs.existsSync(DB)) fs.copyFileSync(DB, f);
    fs.readdirSync(dir).sort().slice(0, -7).forEach(x => fs.unlinkSync(path.join(dir, x)));
  } catch (e) { console.log("backup failed", e.message); }
}
backup(); setInterval(backup, 6 * 3600e3);

/* ---------- API ---------- */
const json = (res, o, status = 200) => { res.writeHead(status, { "content-type": "application/json", "cache-control": "no-store" }); res.end(JSON.stringify(o)); };

async function checkPin(pin) {
  const o = db.owner;
  if (!o) return "none";
  const now = Date.now();
  o.fails = (o.fails || []).filter(t => now - t < 15 * 60000);
  if (o.fails.length >= 8) return "locked";
  if (L.validPin(pin) && (await L.hashPin(o.salt, pin)) === o.hash) return "ok";
  o.fails.push(now); save();
  return "bad";
}
async function setPin(pin) { const salt = L.randHex(16); db.owner = { salt, hash: await L.hashPin(salt, pin), fails: [], updated: Date.now() }; save(); }

const api = {
  async auth(b, res) {
    if (b.check) return json(res, { setup: !db.owner });
    if (!db.owner) {
      if (!L.validPin(b.pin)) return json(res, { error: "PIN must be 4–8 digits" }, 400);
      await setPin(b.pin); return json(res, { ok: true, created: true });
    }
    const r = await checkPin(b.pin);
    if (r === "locked") return json(res, { error: "locked" }, 429);
    if (r !== "ok") return json(res, { error: "wrong" }, 401);
    if (b.newPin !== undefined) {
      if (!L.validPin(b.newPin)) return json(res, { error: "PIN must be 4–8 digits" }, 400);
      await setPin(b.newPin); return json(res, { ok: true, changed: true });
    }
    json(res, { ok: true });
  },

  async sync(b, res) {
    if (!L.validId(b.deviceId)) return json(res, { error: "bad device" }, 400);
    const a = await checkPin(b.pin);
    if (a === "locked") return json(res, { error: "locked" }, 429);
    if (a !== "ok") return json(res, { error: "pin" }, 401);
    const now = Date.now();
    const map = new Map(db.list.tasks.map(t => [t.id, t]));
    for (const raw of (Array.isArray(b.tasks) ? b.tasks : []).slice(0, 800)) {
      const t = L.cleanTask(raw);
      if (!t) continue;
      const cur = map.get(t.id);
      if (!cur || t.u > (cur.u || 0)) map.set(t.id, t);
    }
    let all = [...map.values()].filter(t => !(t.deleted && now - t.u > 30 * 864e5));
    const done = all.filter(t => t.done && !t.deleted).sort((x, y) => (y.doneAt || 0) - (x.doneAt || 0));
    if (done.length > 1000) { const drop = new Set(done.slice(1000).map(t => t.id)); all = all.filter(t => !drop.has(t.id)); }
    db.list = { tasks: all, updated: now };
    const s = b.settings || {};
    const acks = {};
    if (b.acks && typeof b.acks === "object") for (const [k, v] of Object.entries(b.acks).slice(0, 300)) if (Number.isFinite(v)) acks[String(k).slice(0, 40)] = v;
    db.devices[b.deviceId] = {
      sub: L.cleanSub(b.sub), name: typeof b.name === "string" ? b.name.slice(0, 30) : "", acks,
      settings: {
        pre: [0, 5, 15, 30].includes(s.pre) ? s.pre : 0,
        repeat: Math.min(10, Math.max(1, parseInt(s.repeat) || 3)),
        summary: /^\d{2}:\d{2}$/.test(s.summary || "") ? s.summary : "",
        mine: !!s.mine,
      },
      tzOff: Number.isFinite(b.tzOff) ? Math.max(-720, Math.min(840, b.tzOff)) : 330,
      updated: now,
    };

    // expenses: only what changed is exchanged; this is the only process writing, so no conflicts
    let xOut, xNow, xMeta;
    if (Array.isArray(b.exps) || Number.isFinite(b.xSince)) {
      const X = db.exps || (db.exps = { items: [], meta: null, seq: 0 });
      const xm = new Map(X.items.map(x => [x.id, x]));
      const bounce = new Set();
      const stamp = () => (X.seq = Math.max(now, (X.seq || 0) + 1));
      for (const raw of (Array.isArray(b.exps) ? b.exps : []).slice(0, 500)) {
        const x = L.cleanExp(raw);
        if (!x) continue;
        const cur = xm.get(x.id);
        if (!cur || x.u > (cur.u || 0)) { x.s = stamp(); xm.set(x.id, x); }
        else if (x.u < cur.u || JSON.stringify({ ...cur, s: 0 }) !== JSON.stringify({ ...x, s: 0 })) bounce.add(x.id);
      }
      const mt = b.xMeta;
      if (mt && typeof mt === "object" && Number.isFinite(mt.u) && mt.u > ((X.meta && X.meta.u) || 0)) {
        const bud = Number(mt.budget);
        X.meta = { u: Math.round(mt.u), budget: Number.isFinite(bud) && bud > 0 ? Math.min(bud, 1e9) : 0,
          cats: Array.isArray(mt.cats) ? mt.cats.slice(0, 40).filter(c => typeof c === "string" && c).map(c => c.slice(0, 30)) : [] };
      }
      X.items = [...xm.values()].filter(x => !(x.deleted && now - x.u > 180 * 864e5));
      const since = Number.isFinite(b.xSince) ? b.xSince : 0;
      xOut = X.items.filter(x => (x.s || 0) > since || bounce.has(x.id)).map(({ s, ...x }) => x);
      xNow = Math.max(X.seq || 0, now) - 120000;
      xMeta = X.meta || null;
    }

    save(); reschedule();
    json(res, { ok: true, tasks: all, now, exps: xOut, xNow, xMeta });
  },

  async action(b, res) {
    if (!L.validId(b.deviceId) || typeof b.id !== "string") return json(res, { error: "bad request" }, 400);
    const dev = db.devices[b.deviceId];
    if (!dev) return json(res, { ok: false });
    const t = db.list.tasks.find(x => x.id === b.id);
    if (!t || t.done || t.deleted) return json(res, { ok: false });
    const now = Date.now();
    if (b.action === "snooze") t.due = now + 10 * 60000;
    else if (b.action === "done") {
      const nd = L.nextDue(t, now, dev.tzOff ?? 330);
      if (nd) { t.lastDoneAt = now; t.due = nd; } else { t.done = true; t.doneAt = now; }
    } else return json(res, { error: "bad action" }, 400);
    t.u = now; save(); reschedule();
    json(res, { ok: true });
  },

  async test(b, res) {
    if (!L.validId(b.deviceId)) return json(res, { error: "bad device" }, 400);
    const dev = db.devices[b.deviceId];
    if (!dev || !dev.sub) return json(res, { error: "no subscription" }, 404);
    const r = await sendPush(env, dev.sub, { kind: "test", title: "🔔 To Do List", body: "Notifications are working ✓", tag: "test" });
    json(res, { ok: r === "ok", result: r }, r === "ok" ? 200 : 502);
  },
};

/* ---------- reminders: one timer set for the next moment anything is due ---------- */
let timer = null, nextAt = null;
function reschedule() {
  const now = Date.now();
  let next = Infinity;
  for (const [id, dev] of Object.entries(db.devices)) {
    const n = L.computeNext(dev, db.list, db.state[id], now);
    if (n) next = Math.min(next, n);
  }
  clearTimeout(timer); timer = null; nextAt = null;
  if (!Number.isFinite(next)) return;
  nextAt = Math.max(next, now + 500);
  timer = setTimeout(wake, Math.min(nextAt - now, 3600e3)); // re-check at least hourly
}
let waking = false;
async function wake() {
  if (waking) return; waking = true;
  const now = Date.now();
  try {
    if (nextAt && now < nextAt - 1000) return; // hourly re-check, nothing due yet
    for (const t of db.list.tasks) { // roll forward repeating tasks nobody marked done
      if (!t.done && !t.deleted && t.due && t.repeat && t.repeat !== "none" && now - t.due >= 2 * 3600e3) {
        const nd = L.nextDue(t, now); if (nd) { t.due = nd; t.u = now; }
      }
    }
    for (const [id, dev] of Object.entries(db.devices)) {
      if (!dev.sub) continue;
      const s = db.state[id] || (db.state[id] = {});
      s.sent ||= {}; s.pre ||= {};
      if (s.dead && s.dead === dev.sub.endpoint) continue;
      const n = L.computeNext(dev, db.list, s, now);
      if (!n || n > now + 20000) continue;
      const tz = dev.tzOff ?? 330, repeat = dev.settings?.repeat || 3, pre = dev.settings?.pre || 0, acks = dev.acks || {};
      const tasks = L.visibleTasks(dev, db.list);
      const live = new Set();
      let gone = false;
      for (const t of tasks) {
        if (gone) break;
        const k = t.id + ":" + t.due;
        live.add(k);
        if (t.allDay || acks[t.id] === t.due) continue;
        const age = now - t.due;
        if (age >= -20000 && age < 2 * 3600e3) {
          const e = s.sent[k] || { n: 0, at: 0 };
          if (e.n < repeat && now - e.at >= 50000) {
            const body = [L.localTime(t.due, tz), t.cat, t.note].filter(Boolean).join(" · ") + (e.n > 0 ? "  (" + (e.n + 1) + "/" + repeat + ")" : "");
            const r = await sendPush(env, dev.sub, { kind: "due", id: t.id, due: t.due, deviceId: id, title: "🔔 " + t.title, body, tag: "t-" + t.id });
            if (r === "gone") { gone = true; s.dead = dev.sub.endpoint; }
            e.n++; e.at = now; s.sent[k] = e;
          }
        } else if (pre > 0 && t.due > now && t.due - pre * 60000 <= now + 20000 && !s.pre[k]) {
          const r = await sendPush(env, dev.sub, { kind: "pre", id: t.id, deviceId: id, title: "⏰ In " + pre + " min: " + t.title, body: L.localTime(t.due, tz), tag: "p-" + t.id });
          if (r === "gone") { gone = true; s.dead = dev.sub.endpoint; }
          s.pre[k] = 1;
        }
      }
      const sum = dev.settings?.summary;
      if (!gone && sum) {
        const lt = new Date(now + tz * 60000);
        const mins = lt.getUTCHours() * 60 + lt.getUTCMinutes();
        const [sh, sm] = sum.split(":").map(Number);
        const day = L.localDay(now, tz);
        if (mins >= sh * 60 + sm && mins < sh * 60 + sm + 180 && s.summaryDay !== day) {
          const todays = tasks.filter(t => L.localDay(t.due, tz) <= day).sort((a, b) => a.due - b.due);
          const body = todays.length ? todays.slice(0, 5).map(t => (t.allDay ? "📅" : L.localTime(t.due, tz)) + " " + t.title).join("\n") + (todays.length > 5 ? "\n+" + (todays.length - 5) + " more" : "") : "Nothing scheduled for today.";
          await sendPush(env, dev.sub, { kind: "summary", title: "☀️ Today: " + todays.length + " task" + (todays.length === 1 ? "" : "s"), body, tag: "summary" });
          s.summaryDay = day;
        }
      }
      for (const k of Object.keys(s.sent)) if (!live.has(k) && now - s.sent[k].at > 6 * 3600e3) delete s.sent[k];
      for (const k of Object.keys(s.pre)) if (!live.has(k)) delete s.pre[k];
    }
    save();
  } catch (e) { console.log("reminder error", e && e.stack); }
  finally { waking = false; reschedule(); }
}

/* ---------- static files ---------- */
const TYPES = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".png": "image/png", ".webmanifest": "application/manifest+json", ".json": "application/json", ".svg": "image/svg+xml", ".ico": "image/x-icon" };
function serveStatic(req, res) {
  let p = decodeURIComponent(new URL(req.url, "http://x").pathname);
  if (p === "/") p = "/index.html";
  const f = path.normalize(path.join(PUBLIC, p));
  if (!f.startsWith(PUBLIC) || !fs.existsSync(f) || !fs.statSync(f).isFile()) {
    // unknown paths load the app (keeps ?add=1, ?ring=… links working)
    res.writeHead(200, { "content-type": TYPES[".html"], "cache-control": "no-cache" });
    return fs.createReadStream(path.join(PUBLIC, "index.html")).pipe(res);
  }
  const ext = path.extname(f);
  const headers = { "content-type": TYPES[ext] || "application/octet-stream", "x-content-type-options": "nosniff" };
  headers["cache-control"] = ext === ".png" ? "public, max-age=604800" : "no-cache";
  if (p === "/sw.js") headers["service-worker-allowed"] = "/";
  res.writeHead(200, headers);
  fs.createReadStream(f).pipe(res);
}

/* ---------- server ---------- */
const server = http.createServer(async (req, res) => {
  const p = new URL(req.url, "http://x").pathname;
  try {
    if (!p.startsWith("/api/")) return serveStatic(req, res);
    if (p === "/api/config" && req.method === "GET")
      return json(res, { publicKey: env.VAPID_PUBLIC, serverReady: true, host: "self", version: 4, nextReminder: nextAt });
    if (req.method !== "POST") return json(res, { error: "method not allowed" }, 405);
    const name = p.slice(5);
    if (!api[name]) return json(res, { error: "not found" }, 404);
    let body = "";
    for await (const c of req) { body += c; if (body.length > 2e6) return json(res, { error: "too large" }, 413); }
    let b;
    try { b = JSON.parse(body || "{}"); } catch { return json(res, { error: "bad json" }, 400); }
    if (!b || typeof b !== "object") return json(res, { error: "bad body" }, 400);
    await api[name](b, res);
  } catch (e) {
    console.log("error", p, e && e.stack);
    if (!res.headersSent) json(res, { error: "server error" }, 500);
  }
});
server.listen(PORT, HOST, () => { console.log(`To Do List running on http://${HOST}:${PORT}`); reschedule(); });
